/*
project name: inpostresult
program:stack1
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
sets stack characteristics
*/
package inpostresult;
public class stack1<T> {
    int Size;
    Object[] ArrayStack;
    int top;
    public stack1(int Size){
        this.Size=Size;
        ArrayStack=new Object[this.Size];
        top=-1;
    }
    public void push(Object newItem){
        if(IsFull()){
            System.out.println("Stack is full");
            return;
        }
        top=top+1;
        ArrayStack[top]=newItem;
    }
    public T pop(){
        if (IsEmpty()) {
            System.out.println("Stack is empty");
            return null;
        }
        T item = (T) ArrayStack[top];
        top=top-1;
        return item;
    }
    public Boolean IsFull(){
        return (top==Size-1);
    }
    public Boolean IsEmpty(){
        return (top==Size-1);
    }
    char peek() {
        if(IsEmpty()){
            System.out.println("Stack is empty");
            return '`';//fix later
        }else{
            return (char) ArrayStack[top];//may need to change
        }
    }
}
