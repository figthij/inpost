/*
project name:randomarray
program:makearr
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
makes arrays
*/
package randomarray;

import java.util.Random;
public class makearr {
    public void arra(){
        Random rnum = new Random();
        int[] firstArray=new int[10];
    }
    
}
