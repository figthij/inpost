/*
project name: randomarray
program:RandomArray
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
makes array with random numbers
*/
package randomarray;
import java.util.Random;
/*
build an array with 1,000,000 elements with random numbers
build a process that pulls out only the numbers that are factors of three
can't use remainder multiplication or division
produce a report that states how many are factors of 3
*/
public class RandomArray {
    public static void main(String[] args) {
        calc3 calculate = new calc3();
        int[] value = new int[1000000];
        int i =0;
        while(i<1000000){
            inputnum(value,i);
            i=i+1;
        }
        System.out.println(value[0]);
        calculate.calc(value);
    }
    public static void inputnum(int[] value,int i){
    Random rnum = new Random();
    value[i]=rnum.nextInt(1000);
    }
}
/*public class RandomArray {
    public static void main(String[] args) {
        calc3 calculate = new calc3();
        int[] value = new int[1000000];
        int i =0;
        while(i<1000000){
            inputnum(value,i);
            i=i+1;
        }
        System.out.println(value[0]);
        calculate.calc(value);
    }
    public static void inputnum(int[] value,int i){
    Random rnum = new Random();
    value[i]=rnum.nextInt(1000);
    }
    
}
*/   