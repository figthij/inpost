/*
project name: timer
program:Timer
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
sets how the timer is visable
*/
package timer;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.util.concurrent.TimeUnit;
/*
things needed for timer
calculate time 
start time
time passed
seconds passeed
seconds diplayed or the remander of seconds passed and 60
minutes passed
*/
public class Timer extends JFrame {
    JLabel jlabClock;
    numbers n;
//    long startTime = System.currentTimeMillis();
        
    public Timer() {
  /*      long timePassed = System.currentTimeMillis() - startTime;
        long secondsPassed = timePassed / 1000;
        long secondsShown = secondsPassed % 60;
        long minutes = secondsPassed / 60;
        String t= String.valueOf(minutes);
        String i = String.valueOf(secondsShown);
        String m= t+':'+i;
        String e = String.valueOf(timePassed);
*/        jlabClock = new JLabel("Time");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jlabClock.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
        add(jlabClock);
        pack();
        setLocationRelativeTo(null);
        n= new numbers(this);
        setVisible(true);
    }
    public static void main(String[] args) throws InterruptedException { 
        
        new Timer();
            
        /*long startTime = System.currentTimeMillis();
        long timePassed = System.currentTimeMillis() - startTime;
        long secondsPassed = timePassed / 1000;
        long secondsShown = secondsPassed % 60;
        long minutes = secondsPassed / 60;*/
    }
    
}
