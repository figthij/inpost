/*
project name: timer
program:numbers
Author: Erik Bailey
Date: Nov 4 2020
Synoposis: 
makes the timers numbers
*/

package timer;


public class numbers extends Thread{
    Timer t;
    String tim;
    public numbers(Timer t){
        this.t = t;
        start();
    }
    long startTime = System.currentTimeMillis();
    long timePassed = System.currentTimeMillis() - startTime;
        long secondsPassed = timePassed / 1000;
        long secondsShown = secondsPassed % 60;
        long minutes = secondsPassed / 60;
        String ti= String.valueOf(minutes);
        String i = String.valueOf(secondsShown);
        String m= ti+':'+i;
        String e = String.valueOf(timePassed);

    public void run(){
        
        while(true){
            timePassed = System.currentTimeMillis() - startTime;
            secondsPassed = timePassed / 1000;
            secondsShown = secondsPassed % 60;
            minutes = secondsPassed / 60;
            ti= String.valueOf(minutes);
            i = String.valueOf(secondsShown);
            m= ti+':'+i;
            e = String.valueOf(timePassed);
            System.out.println(startTime+"   "+timePassed);
            t.jlabClock.setText(m);
        }
    }
}
